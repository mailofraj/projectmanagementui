import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pmviewtask',
  templateUrl: './pmviewtask.component.html',
  styleUrls: ['./pmviewtask.component.scss']
})
export class PmviewtaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
